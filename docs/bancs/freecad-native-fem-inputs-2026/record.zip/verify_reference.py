import hashlib
import importlib.util
import json
import math
from pathlib import Path
import numpy as np

root=Path(__file__).resolve().parent
axis=np.array((1.,2.,3.));axis/=np.linalg.norm(axis)
x,y,z=axis
cross=np.array(((0,-z,y),(z,0,-x),(-y,x,0)))
angle=math.radians(37)
rotation=np.eye(3)*math.cos(angle)+(1-math.cos(angle))*np.outer(axis,axis)+math.sin(angle)*cross
rows=[]
for case in range(2):
    directory=root/f'case-{case}'
    raw=(directory/'request.json').read_bytes()
    request=json.loads(raw)
    data=json.loads((directory/'preview.json').read_text())
    assert data['request_sha256']==hashlib.sha256(raw).hexdigest()
    assert data['run_id']==request['run_id']
    assert request['young_pa']==210e9 and request['poisson']==0
    traction=[c for c in request['conditions'] if c['kind']=='pressure']
    assert len(traction)==1 and traction[0]['values']==[-2e6]
    frame=np.eye(3) if case==0 else rotation
    shift=np.zeros(3) if case==0 else np.array((.25,-.1,.5))
    points=np.array(data['nodes_m'])
    local=(points-shift)@frame
    assert np.all(local>=-1e-9) and np.all(local<=np.array((.12,.02,.015))+1e-9)
    np.testing.assert_allclose(request['properties_si']['centre_m'],frame@np.array((.06,.01,.0075))+shift,atol=1e-12,rtol=0)
    expected=(2e6/210e9)*local[:,0,None]*frame[:,0]
    displacement_error=float(np.max(np.linalg.norm(np.array(data['displacements_m'])-expected,axis=1)))
    energy=2e6**2*(.12*.02*.015)/(2*210e9)
    energy_error=abs(data['strain_energy_J']/energy-1)
    expected_reaction=-2e6*.02*.015*frame[:,0]
    reaction_error=float(np.linalg.norm(np.array(data['reactions_N']).sum(axis=0)-expected_reaction))
    assert displacement_error<1e-10 and energy_error<5e-6 and reaction_error<5e-6*600
    rows.append({'case':case,'nodes':len(points),'max_displacement_error_m':displacement_error,'relative_energy_error':energy_error,'net_reaction_error_N':reaction_error})
absent=[name for name in ('FreeCAD','vinkulum','vinkulum_studio','OCP','build123d','PySide6') if importlib.util.find_spec(name) is None]
assert len(absent)==6
result={'status':'passed','reference':'Independent affine tension, Rodrigues world-frame transport and analytic energy/reaction balance','cases':rows,'imports_absent':absent}

print(json.dumps(result,indent=2))
