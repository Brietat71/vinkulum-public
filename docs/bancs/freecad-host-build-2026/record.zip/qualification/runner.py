import hashlib,json,subprocess
from pathlib import Path
host=Path('/tmp/vinkulum-freecad-host-recipe-check-v2')
repo=Path('/tmp/vinkulum-freecad-versioned-fingerprint')
output=Path('/tmp/vinkulum-freecad-final-host-qualification')
output.mkdir(exist_ok=False)
r=json.loads((host/'build.json').read_text())
assert r['status']=='built' and all(s.get('status')=='passed' for s in r['steps'])
assert hashlib.sha256((host/'source/build/release/bin/FreeCAD').read_bytes()).hexdigest()==r['binary_sha256']
def manifest():
 base=host/'source/build/release'
 paths=set()
 for folder in ('bin','lib','Mod'):
  for p in (base/folder).rglob('*'):
   if p.is_file() and (p.suffix in ('.py','.so') or '.so.' in p.name or p.parent==base/'bin'):
    paths.add(p)
 return {str(p.relative_to(base)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(paths)}
before=manifest(); (output/'runtime-sha256.json').write_text(json.dumps(before,indent=2)+'\n')
(output/'build.json').write_text(json.dumps(r,indent=2)+'\n')
base=['python3',str(repo/'ci/freecad_static.py'),'--freecad',str(host/'FreeCAD-Vinkulum'),'--engine-python','/tmp/vinkulum-freecad-engine-witness-v2/venv/bin/python','--gmsh','/tmp/vinkulum-mesher-build-recipe/gmsh-install/bin/gmsh','--ccx','/usr/bin/ccx']
results={}
for name,extra in [('pose',[]),('identity',[]),('curved-result',['--rotated']),('reopen',['--result-file',str(output/'curved-result/result.FCStd')]),('task',[])]:
 command=base+['--recipe','static-'+name,'--output',str(output/name)]+extra
 print('Qualify '+name,flush=True)
 with (output/(name+'.log')).open('w') as log:
  subprocess.run(command,cwd=repo,stdout=log,stderr=subprocess.STDOUT,check=True)
 report=json.loads((output/name/'static-check.json').read_text()); assert report['status']=='passed'
 results[name]=report
 (output/'results.json').write_text(json.dumps(results,indent=2)+'\n')
assert manifest()==before,'Runtime files changed during qualification'
(output/'summary.json').write_text(json.dumps({'status':'passed','checks':sum(len(r['checks']) for r in results.values()),'runtime_files':len(before),'runtime_unchanged':True},indent=2)+'\n')
print((output/'summary.json').read_text())
