SetFactory("OpenCASCADE");
General.AbortOnError = 2;
General.NumThreads = 2;
Merge "solid.brep";
v() = Volume{:};
If (#v() != 1)
  Error("Vinkulum requires exactly one imported CAD solid");
  Exit;
EndIf
s() = Surface{:};
For i In {0:#s()-1}
  Physical Surface(Sprintf("Face %g", s(i)), s(i)) = {s(i)};
EndFor
Physical Volume("Solid", 1) = {v()};
Mesh.MeshSizeMin = 2;
Mesh.MeshSizeMax = 10;
Mesh.MeshSizeFromCurvature = 12;
Mesh.Algorithm3D = 10;
Mesh.MaxNumThreads1D = 2;
Mesh.MaxNumThreads2D = 2;
Mesh.MaxNumThreads3D = 2;
Mesh.RandomSeed = 1;
Mesh.ElementOrder = 2;
Mesh.HighOrderOptimize = 2;
Mesh.MshFileVersion = 2.2;
Mesh.Binary = 0;
Mesh.SaveAll = 0;
