"""Run the isolated native stream test; retain all documents and process output."""
import argparse,json,os,signal,subprocess
from pathlib import Path
parser=argparse.ArgumentParser()
parser.add_argument('--freecad',required=True,type=Path)
parser.add_argument('--output',required=True,type=Path)
parser.add_argument('--expect',choices=['passed','counterexample'],required=True)
args=parser.parse_args();root=args.output.absolute();root.mkdir(parents=True,exist_ok=False)
env=os.environ.copy()
for key in ('PYTHONHOME','PYTHONPATH','VIRTUAL_ENV','QT_PLUGIN_PATH','QT_QPA_PLATFORM_PLUGIN_PATH','LD_PRELOAD'):env.pop(key,None)
for key,folder in [('XDG_CONFIG_HOME','config'),('XDG_DATA_HOME','data'),('XDG_CACHE_HOME','cache')]:env[key]=str(root/folder)
env['VINKULUM_STREAM_TEST_OUTPUT']=str(root)
macro=Path(__file__).with_name('qualify.FCMacro');(root/'qualify.FCMacro').write_bytes(macro.read_bytes())
with (root/'console.log').open('w') as log:
 p=subprocess.Popen(['xvfb-run','-a','-s','-screen 0 1600x1100x24',str(args.freecad.absolute()),str(root/'qualify.FCMacro')],env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
 try:code=p.wait(timeout=120)
 finally:
  try:os.killpg(p.pid,signal.SIGTERM)
  except ProcessLookupError:pass
report=json.loads((root/'report.json').read_text())
print(json.dumps({'exit_code':code,'status':report['status'],'cases':[{k:v for k,v in c.items() if k in ('kind','max_vertex_coordinate_difference_mm','reexport_identical','document_vertices_match_fresh_stream')} for c in report['cases']]},indent=2))
assert code==0 and report['status']==args.expect,report
assert 'Traceback (most recent call last)' not in (root/'console.log').read_text()
