"""Régressions de l'audit du noyau : références physiques et sorties d'erreur."""
import math
import subprocess
import sys
import unittest

import numpy as np
from scipy.linalg import expm

from vinkulum import Noyau

J = np.eye(3).ravel().tolist()


def masses(beta=0.0):
    n = Noyau(g=[0, 0, 0])
    for i in range(2):
        n.corps(str(i), 1, J, [i, 0, 0])
    k = np.zeros((12, 12))
    k[0, 0] = k[6, 6] = 100
    k[0, 6] = k[6, 0] = -100
    n.superelement("ressort", [0, 1], k.ravel().tolist(), beta=beta)
    t, r, rot, v, w, vi = n.etat()
    r[1][0] += 0.1
    n.pose_etat(t, r, rot, v, w, vi)
    return n


class AuditNoyau(unittest.TestCase):
    def test_raideur_locale_contre_champ_global(self):
        # Deux poutres partagent un nœud ; les indices ne suivent pas leur
        # ordre géométrique. Déformation, couple et inertie tournante doivent
        # tous apparaître dans la tangente, sans double comptage.
        n = Noyau([0., 0., -9.81])
        for i, p in enumerate(([.8, 0., 0.], [0., 0., 0.], [.4, 0., 0.])):
            n.corps(str(i), 1., [1.,0.,0.,0.,2.,0.,0.,0.,2.], p,
                    w=[.1, .2, .3])
        n.poutre('gauche', 1, 2, 2000., 700., 30., 50., ei3=20.)
        n.poutre('droite', 2, 0, 3000., 800., 40., 70., ei3=25.)
        n.couple('rappel', None, 0, [0.,0.,1.], ('ressort', [5.,.2,.1]))
        t, p, rot, v, w, vi = n.etat()
        p[2][1] += .01
        rot[2] = expm(np.array([[0., -.08, .03], [.08, 0., -.02],
                              [-.03, .02, 0.]])).ravel().tolist()
        n.pose_etat(t, p, rot, v, w, vi)
        k = np.asarray(n.k_c_m_z()[0])
        reference = np.zeros_like(k)
        eps = 1e-5
        for col in range(18):
            body, component = divmod(col, 6)
            values = []
            for sign in (1., -1.):
                pp, rr = np.array(p), np.array(rot).reshape(3,3,3).copy()
                if component < 3:
                    pp[body, component] += sign*eps
                else:
                    d = np.zeros(3); d[component-3] = sign*eps
                    skew = np.array([[0.,-d[2],d[1]], [d[2],0.,-d[0]],
                                     [-d[1],d[0],0.]])
                    rr[body] = expm(skew) @ rr[body]
                n.pose_etat(t, pp.tolist(), rr.reshape(3,9).tolist(), v, w, vi)
                values.append(np.array(n.residu_statique()))
            reference[:,col] = (values[0]-values[1])/(2*eps)
        n.pose_etat(t, p, rot, v, w, vi)
        np.testing.assert_allclose(k, reference, rtol=1e-7, atol=2e-7)
        damping = np.asarray(n.k_c_m_z()[1])
        reference = np.zeros_like(damping)
        eps = 1e-6
        for col in range(18):
            body, component = divmod(col, 6)
            values = []
            for sign in (1., -1.):
                vv, ww = np.array(v), np.array(w)
                if component < 3:
                    vv[body, component] += sign*eps
                else:
                    ww[body, component-3] += sign*eps
                n.pose_etat(t, p, rot, vv.tolist(), ww.tolist(), vi)
                values.append(np.array(n.residu_statique()))
            reference[:,col] = (values[0]-values[1])/(2*eps)
        n.pose_etat(t, p, rot, v, w, vi)
        np.testing.assert_allclose(damping, reference, rtol=1e-6, atol=2e-7)

    def test_poutre_raideur_timoshenko(self):
        # Matrice nodale analytique, dans les deux plans anisotropes.
        n = Noyau([0., 0., 0.])
        length, ea, gay, gaz, gj, eiy, eiz = .9, 10000., 700., 900., 30., 50., 20.
        for i in range(2):
            n.corps(str(i), 1., J, [i*length, 0., 0.])
        n.poutre('p', 0, 1, ea, gay, gj, eiy, ei3=eiz, ga3=gaz, formulation="integree")
        expected = np.zeros((12, 12))
        for indices, stiff in (([0, 6], ea), ([3, 9], gj)):
            expected[np.ix_(indices, indices)] = stiff/length*np.array([[1., -1.], [-1., 1.]])
        for indices, ei, ga, signs in (([1, 5, 7, 11], eiz, gay, [1, 1, 1, 1]),
                                       ([2, 4, 8, 10], eiy, gaz, [1, -1, 1, -1])):
            l, phi = length, 12*ei/(ga*length**2)
            block = ei/(l**3*(1+phi))*np.array([
                [12, 6*l, -12, 6*l],
                [6*l, (4+phi)*l*l, -6*l, (2-phi)*l*l],
                [-12, -6*l, 12, -6*l],
                [6*l, (2-phi)*l*l, -6*l, (4+phi)*l*l]])
            expected[np.ix_(indices, indices)] = block*np.outer(signs, signs)
        np.testing.assert_allclose(n.k_c_m_z()[0], expected, rtol=1e-6, atol=1e-6)

    def test_poutre_arc_moment_pur(self):
        # Un moment constant donne un arc circulaire. La même solution doit
        # tenir après rotation et translation du modèle dans le monde.
        skew = np.array([[0., -.3, .2], [.3, 0., -.1], [-.2, .1, 0.]])
        origin = np.array([-.4, .2, .1])
        for frame in (np.eye(3), expm(skew)):
            for theta in (.01, 1., 2.5):
                n = Noyau([0., 0., 0.])
                for i in range(2):
                    n.corps(str(i), 1., J, (origin+frame@np.array([float(i), 0., 0.])).tolist(),
                            rot=frame.ravel().tolist())
                n.liaison('enc', None, 0, pa=origin.tolist(), bloque_t=[0, 1, 2], bloque_r=[0, 1, 2])
                n.poutre('p', 0, 1, 1e6, 1e5, 50., 100., formulation='integree')
                n.effort(1, [0., 0., 0.], (frame@np.array([0., 0., 100.*theta])).tolist())
                n.statique(tol=1e-9, iters=100)
                exact = origin+frame@np.array([math.sin(theta)/theta, (1-math.cos(theta))/theta, 0.])
                np.testing.assert_allclose(n.pose(1)[0], exact, atol=2e-8, rtol=0)
                self.assertLess(np.max(np.abs(n.residu_statique()[6:])), 1e-5)
                self.assertLess(np.max(np.abs(n.phi())), 1e-9)

    def test_poutre_sensibilites_condensation(self):
        # La condensation dépend de GA ET EI : dériver seulement les termes
        # de courbure donne une fausse sensibilité, même si l'équilibre passe.
        base = np.array([2000., 700., 30., 50., 20., 900.])
        def modele(params):
            ea, ga, gj, ei, ei3, ga3 = params
            n = Noyau([0., 0., 0.])
            for i in range(2):
                n.corps(str(i), 1., J, [.9*i, 0., 0.])
            n.poutre('p', 0, 1, ea, ga, gj, ei, ei3=ei3, ga3=ga3, formulation="integree")
            state = list(n.etat())
            state[1][1] = [.91, .03, -.02]
            state[2][1] = expm(np.array([[0., -.2, .1], [.2, 0., -.3], [-.1, .3, 0.]])).ravel().tolist()
            n.pose_etat(*state)
            return n
        n = modele(base)
        for key, indices in {'ea':[0], 'ga':[1, 5], 'gj':[2], 'ei':[3, 4],
                             'ei_e2':[3], 'ei_e3':[4]}.items():
            delta = min(base[indices])*1e-4
            pp, pm = base.copy(), base.copy()
            pp[indices] += delta
            pm[indices] -= delta
            plus, minus = modele(pp), modele(pm)
            force = (np.array(plus.residu_statique())-minus.residu_statique())/(2*delta)
            stiffness = (np.array(plus.k_c_m_z()[0])-minus.k_c_m_z()[0])/(2*delta)
            np.testing.assert_allclose(n.d_residu_poutre(0, key), force, rtol=1e-6, atol=1e-8)
            np.testing.assert_allclose(n.d_raideur_poutre(0, key), stiffness, rtol=2e-5, atol=3e-5)

    def test_statique_poutre_anisotrope_amortie(self):
        # Charge hors des axes principaux : l'ancien amortissement stagne,
        # même par 512 paliers. Référence MBDyn raffinée à 160 intervalles.
        ref = np.array([0.4936103410461536, 0.1090430831170913,
                        0.00888888595701552])
        for formulation in ("milieu", "integree"):
            erreurs = []
            for ne in (10, 20, 40):
                n = Noyau([0., 0., 0.])
                ids = [n.corps(str(i), 1., J, [.508*i/ne, 0., 0.])
                       for i in range(ne+1)]
                n.liaison('enc', None, ids[0], bloque_t=[0, 1, 2],
                          bloque_r=[0, 1, 2])
                for i in range(ne):
                    n.poutre(str(i), ids[i], ids[i+1], 2.84191e6, 6.40131e5,
                             3.10338, 36.2794, ei3=2.42873, ga3=9.03881e5, formulation=formulation)
                n.effort(ids[-1], [0., 8.896/math.sqrt(2), 8.896/math.sqrt(2)],
                         [0., 0., 0.])
                _, iterations = n.statique(tol=1e-8, iters=60, paliers_max=1)
                self.assertLess(iterations, 60)
                self.assertLess(max(map(abs, n.phi())), 1e-10)
                self.assertLess(np.max(np.abs(n.residu_statique()[6:])), 1e-7)
                erreurs.append(np.max(np.abs(np.array(n.pose(ids[-1])[0])-ref)))
            self.assertLess(erreurs[1], 7e-5)
            self.assertLess(erreurs[1], erreurs[0]/3)
            self.assertLess(erreurs[2], 2e-5)
            self.assertLess(erreurs[2], erreurs[1]/3)
            if formulation == "integree":
                for error, limit in zip(erreurs, (5.5e-6, 1.4e-6, 4e-7)):
                    self.assertLess(error, limit)

    def test_statut_statique_et_mode_strict(self):
        import warnings
        n = Noyau([0., 0., 0.])
        n.corps('libre', 1., J, [0., 0., 0.])
        self.assertIsNone(n.statique_info())
        n.statique(strict=True, paliers_max=1)
        info = n.statique_info()
        self.assertEqual(info['statut'], 'tolerance')
        self.assertTrue(info['tolerance_finale_atteinte'])
        self.assertEqual(info['evaluations'], 1)
        self.assertEqual(info['tentatives'], 1)
        info['statut'] = 'modifie'
        self.assertEqual(n.statique_info()['statut'], 'tolerance')

        # Un corps libre sous force constante n'a AUCUN équilibre. Le seuil
        # de stagnation historique l'acceptait car la force est petite.
        n.effort(0, [5e-7, 0., 0.], [0., 0., 0.])
        before = n.etat()
        with self.assertWarnsRegex(RuntimeWarning, 'stagnation'):
            residual, iterations = n.statique(tol=1e-12, iters=12, paliers_max=1)
        info = n.statique_info()
        self.assertEqual(info['statut'], 'stagnation')
        self.assertFalse(info['tolerance_finale_atteinte'])
        self.assertEqual(info['paliers_stagnation'], 1)
        self.assertEqual(info['echelle_force'], 1.)
        self.assertAlmostEqual(info['residu_libre'], 5e-7)
        self.assertEqual(info['residu_libre'], residual)
        self.assertEqual(info['evaluations'], iterations+1)
        self.assertFalse(info['etat_restaure'])

        with self.assertRaises(RuntimeError):
            n.statique(tol=1e-12, iters=12, paliers_max=1, strict=True)
        info = n.statique_info()
        self.assertEqual(info['statut'], 'echec')
        self.assertTrue(info['strict'])
        self.assertTrue(info['etat_restaure'])
        self.assertFalse(info['tolerance_finale_atteinte'])
        self.assertGreaterEqual(info['tentatives'], 2)
        self.assertEqual(info['paliers_stagnation'], 0)
        self.assertEqual(n.etat(), before)

        # Transformer l'avertissement en exception doit aussi restaurer le
        # modèle, comme tout autre appel statique qui échoue.
        with warnings.catch_warnings():
            warnings.simplefilter('error', RuntimeWarning)
            with self.assertRaises(RuntimeWarning):
                n.statique(tol=1e-12, iters=12, paliers_max=1)
        self.assertTrue(n.statique_info()['etat_restaure'])
        self.assertEqual(n.statique_info()['statut'], 'echec')
        self.assertEqual(n.etat(), before)
        with self.assertRaises(ValueError):
            n.statique(tol=-1.)
        self.assertIsNone(n.statique_info())

    def test_statique_warning_restaure_pose_modifiee(self):
        import warnings
        n = masses()
        n.effort(1, [0., 5e-7, 0.], [0., 0., 0.])
        before = n.etat()
        # Le ressort se détend effectivement avant que la direction neutre
        # chargée fasse stagner le solveur : la restauration n'est pas vide.
        with self.assertWarns(RuntimeWarning):
            n.statique(tol=1e-12, iters=15, paliers_max=1)
        self.assertNotEqual(n.etat(), before)
        self.assertAlmostEqual(n.pose(0)[0][0], .05, places=10)
        n.pose_etat(*before)
        with warnings.catch_warnings():
            warnings.simplefilter('error', RuntimeWarning)
            with self.assertRaises(RuntimeWarning):
                n.statique(tol=1e-12, iters=15, paliers_max=1)
        self.assertEqual(n.etat(), before)
        self.assertTrue(n.statique_info()['etat_restaure'])
        self.assertEqual(n.statique_info()['statut'], 'echec')

    def test_statique_reaction_ne_masque_pas_equilibre(self):
        # Une charge entièrement reprise par le guide ne change pas la
        # flèche libre F/k et ne doit pas changer son seuil de convergence.
        for reaction in (0., 1e12):
            for initial in (0., .09):
                n = Noyau([0., 0., 0.])
                for i in range(2):
                    n.corps(str(i), 1., J, [0., 0., 0.])
                n.liaison('base', None, 0, bloque_t=[0, 1, 2], bloque_r=[0, 1, 2])
                n.liaison('guide', None, 1, bloque_t=[0, 1], bloque_r=[0, 1, 2])
                k = np.zeros((12, 12))
                k[np.ix_([2, 8], [2, 8])] = 10*np.array([[1., -1.], [-1., 1.]])
                n.superelement('rappel', [0, 1], k.ravel().tolist())
                n.effort(1, [reaction, 0., 1.], [0., 0., 0.])
                state = list(n.etat())
                state[1][1][2] = initial
                n.pose_etat(*state)
                before = n.etat()
                # Budget insuffisant : refuser le faux succès et restaurer
                # exactement la pose avant de permettre le vrai Newton.
                with self.assertRaises(RuntimeError):
                    n.statique(tol=1e-10, iters=1, paliers_max=1)
                self.assertEqual(n.etat(), before)
                residual, iterations = n.statique(tol=1e-10, iters=20, paliers_max=1, strict=True)
                self.assertGreater(iterations, 0)
                self.assertLess(residual, 1e-10)
                self.assertAlmostEqual(n.pose(1)[0][2], .1, places=12)
                self.assertLess(abs(n.residu_statique()[8]), 1e-10)
                self.assertLess(max(map(abs, n.phi())), 1e-10)

    def test_statique_singuliere_grande_dimension(self):
        # Au-delà du seuil creux : chaque corps garde cinq directions neutres.
        # Le repli doit résoudre l'équilibre sans déplacer ces directions.
        n = Noyau([0., 0., 0.])
        for i in range(30):
            c = n.corps(str(i), 1., J, [.1*i, 0., 0.])
            n.couple(str(i), None, c, [0.,0.,1.], ('ressort', [100.,0.,.1]))
        n.statique(tol=1e-10, iters=30, paliers_max=1)
        self.assertLess(np.max(np.abs(n.residu_statique())), 1e-8)
        for i in range(30):
            p, r = n.pose(i)
            np.testing.assert_allclose(p, [.1*i, 0., 0.], atol=1e-12)
            self.assertAlmostEqual(math.atan2(r[3], r[0]), .1, places=10)

    def test_engrenages_fractionnaires_plusieurs_tours(self):
        from concurrent.futures import ThreadPoolExecutor
        def tourne(ratio):
            n = Noyau(g=[0, 0, 0])
            for i, w in enumerate((ratio * 2, 2)):
                n.corps(str(i), 1, J, [i, 0, 0], w=[0, 0, w])
                n.liaison('p'+str(i), None, i, pa=[i, 0, 0], bloque_r=[0, 1])
            n.engrenage('g', 0, 1, [0, 0, 1], [0, 0, 1], ratio)
            n.simule(20., .02, tous=100)
            for i, vitesse in enumerate((ratio * 2, 2)):
                R = np.array(n.etat()[2][i]).reshape(3, 3)
                angle = vitesse * n.t()
                ref = np.array([[math.cos(angle), -math.sin(angle), 0],
                                [math.sin(angle), math.cos(angle), 0], [0, 0, 1]])
                np.testing.assert_allclose(R, ref, atol=1e-9)
                self.assertAlmostEqual(n.etat()[4][i][2], vitesse, places=10)
            self.assertLess(np.linalg.norm(n.phi()), 1e-10)
            return n.etat()
        rapports = (1.5, -2.3, math.sqrt(2), 2.)
        serie = [tourne(r) for r in rapports]
        with ThreadPoolExecutor(max_workers=4) as pool:
            parallele = list(pool.map(tourne, rapports))
        self.assertEqual(serie, parallele)

    def test_temps_petits_et_reprise(self):
        for methode in ('simule', 'simule_em', 'simule_multirythme'):
            for t0 in (0., 1e-6):
                n = Noyau(g=[0, 0, -9.81])
                for i in range(2):
                    n.corps(str(i), 1, J, [0, 0, 0], v=[1, 0, 0])
                etat = list(n.etat())
                etat[0] = t0
                n.pose_etat(*etat)
                fin = t0 + 5e-13
                kw = dict(rapides=[1], k=2) if methode == 'simule_multirythme' else {}
                getattr(n, methode)(fin, 1e-13, **kw)
                self.assertEqual(n.t(), fin, methode)
                for r, v in zip(n.etat()[1], n.etat()[3]):
                    self.assertAlmostEqual(r[0] / (fin-t0), 1., places=12)
                    self.assertAlmostEqual(v[2] / (fin-t0), -9.81, places=10)

    def test_temps_non_representable_restaure(self):
        for methode in ('simule', 'simule_em', 'simule_multirythme'):
            n = Noyau(g=[0, 0, 0])
            n.corps('a', 1, J, [0, 0, 0])
            etat = list(n.etat())
            etat[0] = 1e16
            n.pose_etat(*etat)
            before = n.etat()
            kw = dict(rapides=[0], k=2) if methode == 'simule_multirythme' else {}
            with self.assertRaisesRegex(RuntimeError, 'progresser le temps'):
                getattr(n, methode)(1e16+4, .1, **kw)
            self.assertEqual(n.etat(), before)

    def test_modes_zero_et_temps_invalides(self):
        for n in (Noyau(), masses()):
            for f in (n.modes, n.modes_complexes):
                self.assertEqual(f(0), [])
                with self.assertRaises(RuntimeError):
                    f(0, t=math.nan)
        self.assertEqual(Noyau().modes(), [])
        self.assertEqual(Noyau().modes_complexes(), [])

    def test_debordement_modal_exception_bornee(self):
        code = '''
from vinkulum import Noyau
import numpy as np
n = Noyau(g=[0, 0, 0])
for i in range(2):
    n.corps(str(i), 1e-300, np.eye(3).ravel().tolist(), [i, 0, 0])
k = np.zeros((12, 12))
k[0, 0] = k[6, 6] = 1e100
k[0, 6] = k[6, 0] = -1e100
n.superelement('s', [0, 1], k.ravel().tolist())
for f in (n.modes, n.modes_complexes, n.spectre, n.bilan_stabilite):
    try:
        f()
    except RuntimeError:
        pass
    else:
        raise AssertionError('débordement accepté')
'''
        p = subprocess.run([sys.executable, '-c', code], capture_output=True,
                           text=True, timeout=10)
        self.assertEqual(p.returncode, 0, p.stderr)

    def test_statique_geometrie_independante_charge(self):
        for masse in (1., 1e10):
            n = Noyau(g=[0, 0, -9.81])
            n.corps('a', masse, J, [0, 0, 0])
            n.liaison('fixe', None, 0)
            etat = list(n.etat())
            etat[1][0][0] = .1
            n.pose_etat(*etat)
            n.statique(paliers_max=1)
            self.assertLess(np.linalg.norm(n.phi()), 1e-10)
            self.assertAlmostEqual(abs(n.reactions()[0][1][2]) / masse, 9.81, places=10)

    def test_statique_et_tangentes_date_servo(self):
        n = Noyau(g=[0, 0, 0])
        n.corps('a', 1, J, [0, 0, 0])
        n.liaison('pivot', None, 0, bloque_r=[0, 1])
        n.couple('servo', None, 0, [0, 0, 1], ('pd', [10, 1, 2, 100]),
                 cible=('lineaire', [0, .5]))
        # Tangentes analytiques de la saturation tanh et de la limite de vitesse.
        K, C, *_ = n.k_c_m_z(t=1.)
        self.assertAlmostEqual(K[5][5], 10 / math.cosh(2.5)**2, places=8)
        self.assertAlmostEqual(C[5][5], 1 / math.cosh(2.5)**2 + math.tanh(2.5)/100, places=8)
        self.assertGreater(abs(n.k_c_m_z(t=0.)[0][5][5]), 9.)
        # Une limite de couple large évite une tangente nulle au Newton initial.
        n2 = Noyau(g=[0, 0, 0])
        n2.corps('a', 1, J, [0, 0, 0])
        n2.liaison('pivot', None, 0, bloque_r=[0, 1])
        n2.couple('servo', None, 0, [0, 0, 1], ('pd', [10, 1, 100, 100]),
                  cible=('lineaire', [0, .5]))
        n2.statique(t=1.)
        R = np.array(n2.etat()[2][0]).reshape(3, 3)
        self.assertAlmostEqual(math.atan2(R[1, 0], R[0, 0]), .5, places=9)
        self.assertEqual(n2.t(), 0.)  # date d'analyse, sans avancer l'horloge

    def test_base_admissible_bras_et_redondance(self):
        from scipy.linalg import null_space
        for L in (1e-5, 1., 1e4, 1e5, 1e8):
            for double in (False, True):
                n = Noyau(g=[0, 0, 0])
                n.corps('a', 1, J, [L, 0, 0])
                n.liaison('rotule', None, 0, bloque_r=[])
                if double:
                    n.liaison('doublon', None, 0, bloque_r=[])
                _, _, _, Z, G = n.k_c_m_z()
                Z, G = np.array(Z), np.array(G)
                self.assertEqual(Z.shape, (6, 3))
                G /= np.linalg.norm(G, axis=1)[:, None]
                reference = null_space(G)
                np.testing.assert_allclose(Z.T @ Z, np.eye(3), atol=2e-14)
                self.assertLess(np.linalg.norm(G @ Z), 1e-13)
                np.testing.assert_allclose(Z @ Z.T, reference @ reference.T, atol=1e-13)

    def test_sensibilites_poutre_isolees(self):
        def modele(ea, parasite):
            n = Noyau(g=[0, 0, 0])
            for i in range(3):
                n.corps(str(i), 1, J, [i, 0, 0])
            n.poutre('p', 0, 1, ea, 20, 30, 40)
            if parasite:
                k = np.kron([[1., -1.], [-1., 1.]], np.eye(6)) * 100
                n.superelement('s', [1, 2], k.ravel().tolist())
                n.contact('sol', 2, [0, 0, 0], 0, normale=[0, 0, 1],
                          origine=[0, 0, .1], k=1000)
            etat = list(n.etat())
            etat[1][1][0] += .1
            etat[1][1][1] += .02
            n.pose_etat(*etat)
            return n
        n = modele(10, True)
        seul = modele(10, False)
        for methode in ('d_residu_poutre', 'd_raideur_poutre'):
            np.testing.assert_allclose(getattr(n, methode)(0, 'ea'),
                                       getattr(seul, methode)(0, 'ea'), atol=1e-13)
        delta = .01
        plus, moins = modele(10+delta, True), modele(10-delta, True)
        ref = (np.array(plus.residu_statique()) - moins.residu_statique()) / (2*delta)
        np.testing.assert_allclose(n.d_residu_poutre(0, 'ea'), ref, atol=1e-10)
        ref_k = (np.array(plus.k_m_z()[0]) - moins.k_m_z()[0]) / (2*delta)
        np.testing.assert_allclose(n.d_raideur_poutre(0, 'ea'), ref_k, atol=1e-6)

    def test_liaison_axes_repetes_et_axes_extremes(self):
        n = Noyau()
        n.corps('a', 1, J, [0, 0, 0])
        for kw in (dict(bloque_r=[0, 1, 2, 0]), dict(bloque_t=[0, 0]),
                   dict(cible_r=([1e308, 0, 0], ('constante', [1])))):
            with self.assertRaises(ValueError):
                n.liaison('invalide', None, 0, **kw)
        self.assertEqual(n.phi(), [])
        with self.assertRaises(ValueError):
            n.couple('invalide', None, 0, [1e308, 0, 0], ('constant', [1]))
        self.assertEqual(n.couples(), [])

    def test_contact_maillage_meme_corps_refuse(self):
        n = Noyau()
        n.corps('a', 1, J, [0, 0, 0])
        mi = n.maillage('m', 0, [0, 0, 0, 1, 0, 0, 0, 1, 0], [0, 1, 2])
        with self.assertRaises(ValueError):
            n.contact('auto', 0, [0, 0, 0], .1, maille=mi)
        self.assertEqual(n.contacts(), [])

    def test_parametres_non_finis_et_inertie_relative(self):
        n = Noyau(g=[0, 0, 0])
        mauvais = np.eye(3) * 1e-15
        mauvais[0, 1] = 1e-16
        with self.assertRaises(ValueError):
            n.corps('asymetrique', 1, mauvais.ravel().tolist(), [0, 0, 0])
        self.assertEqual(len(n.etat()[1]), 0)
        n.corps('valide', 1, (np.eye(3)*1e-15).ravel().tolist(), [0, 0, 0])
        for params in ([1, 1, 0, 1], [1, 1, 1, 0]):
            with self.assertRaises(ValueError):
                n.couple('pd', None, 0, [0, 0, 1], ('pd', params),
                         cible=('constante', [0]))
        for kw in (dict(v_eps=math.inf), dict(d_hat=math.nan),
                   dict(normale=[1e308, 0, 0])):
            with self.assertRaises(ValueError):
                n.contact('invalide', 0, [0, 0, 0], .1, **kw)
        with self.assertRaises(ValueError):
            n.inflow([1e308, 0, 0], 1, 1)
        self.assertEqual(n.contacts(), [])
        self.assertEqual(n.couples(), [])

    def test_oscillateur_super_convergence(self):
        for beta in (0.0, 0.02):
            ref = expm(np.array([[0, 1], [-200, -200 * beta]]) * 0.1) @ [0.1, 0]
            errors = []
            for h in (0.002, 0.001, 0.0005):
                n = masses(beta)
                n.simule(0.1, h)
                _, r, _, v, _, _ = n.etat()
                got = np.array([r[1][0] - r[0][0] - 1, v[1][0] - v[0][0]])
                errors.append(np.linalg.norm(got - ref))
                self.assertLess(abs(r[0][0] + r[1][0] - 1.1), 1e-12)
            self.assertLess(errors[-1], 2e-5)
            self.assertTrue(all(a / b > 3.7 for a, b in zip(errors, errors[1:])), errors)

    def test_super_jacobien(self):
        n = masses(0.02)
        n.liaison("support", None, 0)
        for ggl in (False, True):
            before = n.etat()
            blocs, _ = n.audit_jacobien(0.01, ggl=ggl)
            self.assertEqual(before, n.etat())
            self.assertLess(max(b[1] for b in blocs), 1e-6)

    def test_super_branche_pi(self):
        n = masses()
        # Un second superélément porte une raideur de torsion.
        k = np.zeros((12, 12))
        k[3, 3] = k[9, 9] = 1
        k[3, 9] = k[9, 3] = -1
        n.superelement("torsion", [0, 1], k.ravel().tolist())
        t, r, rot, v, w, vi = n.etat()
        rot[1] = [1, 0, 0, 0, -1, 0, 0, 0, -1]
        n.pose_etat(t, r, rot, v, w, vi)
        self.assertAlmostEqual(abs(n.residu_statique()[9]), math.pi, places=12)
        before = n.etat()
        with self.assertRaises(RuntimeError):
            n.audit_jacobien(.001)
        self.assertEqual(before, n.etat())

    def test_statique_debordement_restaure(self):
        n = Noyau(g=[0, 0, 0])
        n.corps("a", 1, J, [0, 0, 0])
        n.effort(0, [1e308, 1e308, 0], [0, 0, 0])
        before = n.etat()
        with self.assertRaises(RuntimeError):
            n.statique(paliers_max=1, iters=3)
        self.assertEqual(before, n.etat())

    def test_poutre_pi_modes_refuses_sans_panique(self):
        n = Noyau(g=[0, 0, 0])
        n.corps("a", 1, J, [0, 0, 0])
        n.corps("b", 1, J, [1, 0, 0])
        n.poutre("p", 0, 1, 1, 1, 1, 1)
        t, r, rot, v, w, vi = n.etat()
        rot[1] = [1, 0, 0, 0, -1, 0, 0, 0, -1]
        n.pose_etat(t, r, rot, v, w, vi)
        with self.assertRaisesRegex(RuntimeError, "tangente non différentiable"):
            n.modes()

    def test_super_rotation_rigide_amortissement(self):
        n = Noyau(g=[0, 0, 0])
        n.corps("a", 1, J, [0, 0, 0], w=[0, 0, 1])
        n.corps("b", 1, J, [1, 0, 0], v=[0, 1, 0], w=[0, 0, 1])
        k = np.kron([[1., -1.], [-1., 1.]], np.eye(6))
        n.superelement("s", [0, 1], k.ravel().tolist(), beta=1)
        self.assertLess(np.linalg.norm(n.residu_statique()), 1e-13)

    def test_super_domaine_energie(self):
        for action in (lambda n: n.simule_em(.1, .01), lambda n: n.simule(.1, .01, energie=True)):
            n = masses()
            before = n.etat()
            with self.assertRaises((ValueError, RuntimeError)):
                action(n)
            self.assertEqual(before, n.etat())

    def test_energie_moment_divergence(self):
        for h in (.1, 1., 3., 10., 100.):
            n = Noyau(g=[0, 0, 0])
            n.corps("a", 1, np.diag([1, 2, 3]).ravel().tolist(), [0, 0, 0], w=[1, 2, 3])
            before = n.etat()
            l = np.array(n.moment())
            e = n.energie()
            try:
                n.simule_em(h, h)
            except RuntimeError:
                self.assertEqual(before, n.etat())
            else:
                self.assertLess(abs(n.energie() / e - 1), 1e-12)
                self.assertLess(np.linalg.norm(np.array(n.moment()) - l), 1e-11)

    def test_reprise_multi_echec(self):
        n = Noyau(g=[0, 0, -9.81])
        for i in range(2):
            n.corps(str(i), 1, J, [i, 0, 0])
        # Une partition lente avec liaison non linéaire exige >1 correction.
        n.distance("d", None, 1, [0, 0, 0], [0, 0, 0], l=1)
        before = n.etat()
        with self.assertRaises(RuntimeError):
            n.simule_multirythme(.1, .01, [0], 2, newton_max=1, tol=1e-30)
        self.assertEqual(before, n.etat())
        n.simule(.01, .001)
        self.assertAlmostEqual(n.etat()[1][0][2], -.0004905, places=12)

    def test_multi_partitions_et_contraintes(self):
        def monte():
            n = Noyau(g=[0, 0, -9.81])
            for i in range(4):
                n.corps(str(i), 1, J, [i, 0, -1], v=[0, .2, 0])
                n.distance('d'+str(i), None, i, [i, 0, 0], [0, 0, 0], l=1)
            # Redondance dans une partition, sans liaison traversante.
            n.distance('double', None, 2, [2, 0, 0], [0, 0, 0], l=1)
            return n
        reference = monte()
        reference.simule(.0125, .001)
        for rapides in ([], [0, 1, 2, 3], [0, 2]):
            n = monte()
            n.simule_multirythme(.0125, .001, rapides, 1)
            self.assertEqual(n.t(), .0125)
            for champ in (1, 2, 3, 4):
                np.testing.assert_allclose(n.etat()[champ], reference.etat()[champ], atol=1e-9, rtol=1e-9)
            np.testing.assert_allclose([r[1] for r in n.reactions()],
                                       [r[1] for r in reference.reactions()], atol=1e-8, rtol=1e-8)
            self.assertLess(np.linalg.norm(n.phi()), 1e-10)
            n.simule_multirythme(.014, .001, [1, 3], 2)
            self.assertEqual(n.t(), .014)
            self.assertLess(np.linalg.norm(n.phi()), 1e-10)

    def test_reprise_multi_echec_rapide(self):
        n = Noyau(g=[0, 0, -9.81])
        for i in range(2):
            n.corps(str(i), 1, J, [i, 0, 0])
        n.distance('d', None, 1, [0, 0, 0], [0, 0, 0], l=1)
        before = n.etat()
        with self.assertRaises(RuntimeError):
            n.simule_multirythme(.1, .01, [1], 2, newton_max=1, tol=1e-30)
        self.assertEqual(before, n.etat())
        n.simule(.01, .001)
        self.assertAlmostEqual(n.etat()[1][0][2], -.0004905, places=12)

    def test_multi_echec_apres_macro_pas(self):
        # Un couple déborde seulement après deux macro-pas acceptés.
        def monte(rapide):
            n = Noyau(g=[0, 0, -9.81])
            for i in range(2):
                n.corps(str(i), 1, J, [i, 0, 0])
            n.couple('retarde', None, int(rapide), [0, 0, 1],
                     ('pd', [1e200, 0, 1e200, 1e200]),
                     cible=('table', [0, 0, .002, 0, .003, 1]))
            return n
        for rapide in (False, True):
            n, ref = monte(rapide), monte(rapide)
            ref.simule_multirythme(.002, .001, [1], 2)
            with self.assertRaises(RuntimeError):
                n.simule_multirythme(.004, .001, [1], 2)
            self.assertEqual(n.t(), .002)
            self.assertEqual(n.etat(), ref.etat())

    def test_appariement_modification_loi(self):
        n = Noyau(g=[0, 0, 0])
        for i in range(2):
            n.corps(str(i), 1, J, [i * 1.9, 0, 0])
            n.sphere(i, [0, 0, 0], 1)
        n.appariement(k=1, expo=1)
        n.simule(1e-5, 1e-5)
        n.appariement(k=100, expo=1)
        n.simule(2e-5, 1e-5)
        _, d, f = n.contacts()[0]
        self.assertAlmostEqual(f, 100 * d, places=12)

    def test_gardes_atomiques(self):
        actions = [
            lambda n: n.effort(0, [math.nan, 0, 0], [0, 0, 0]),
            lambda n: n.superelement("bad", [0, 1], [math.nan] * 144),
            lambda n: n.superelement("bad", [0, 1], [0.] * 144, alpha=1),
            lambda n: n.simule(.1, .01, pas_contact=(0, 0, .1)),
            lambda n: n.simule(.1, .01, tol=math.nan),
            lambda n: n.simule(.1, .01, bornes=(2, 1)),
            lambda n: n.simule(.1, .01, newton_max=0),
            lambda n: n.statique(tol=math.nan),
            lambda n: n.couple("vide", None, 0, [0, 0, 1], ("ressort", [])),
        ]
        for method in ("simule", "simule_em", "simule_multirythme"):
            for bad in (math.nan, math.inf, -.1):
                def action(n, method=method, bad=bad):
                    kw = dict(rapides=[0], k=2) if method == "simule_multirythme" else {}
                    getattr(n, method)(bad, .01, **kw)
                actions.append(action)
        for action in actions:
            n = masses()
            before = n.etat()
            with self.assertRaises(ValueError):
                action(n)
            self.assertEqual(before, n.etat())

    def test_pas_contact_termine(self):
        code = '''from vinkulum import Noyau
n=Noyau(g=[0,0,-9.81]);n.corps("a",1,[1,0,0,0,1,0,0,0,1],[1,0,0])
n.distance("d",None,0,[0,0,0],[0,0,0],l=1)
try: n.simule(.1,.01,newton_max=1,tol=1e-30,pas_contact=(.01,.01,.01))
except RuntimeError: pass
print("termine")
'''
        r = subprocess.run([sys.executable, "-c", code], capture_output=True, text=True, timeout=5)
        self.assertEqual(r.returncode, 0, r.stderr)
        self.assertEqual(r.stdout.strip(), "termine")


if __name__ == "__main__":
    unittest.main()
