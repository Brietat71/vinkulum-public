"""CAD operation dialog. Native geometry runs outside the desktop process."""

from dataclasses import asdict
from pathlib import Path

from PySide6.QtCore import QTimer, Signal, Slot
from PySide6.QtWidgets import (
    QComboBox,
    QDialog,
    QDialogButtonBox,
    QDoubleSpinBox,
    QFileDialog,
    QFormLayout,
    QLabel,
    QLineEdit,
    QPushButton,
    QVBoxLayout,
)

from .cad_controller import CadController
from .controls import NumberField
from .sketch import bracket_profile


class CadDialog(QDialog):
    completed = Signal(object)

    def __init__(self, project, selection, parent=None):
        super().__init__(parent)
        self.setWindowTitle("CAD design · OCCT 8 / build123d")
        self.setMinimumWidth(430)
        self.project = project
        self.controller = CadController(self, project=project)
        self.controller.completed.connect(self._completed)
        self.controller.failed.connect(
            lambda kind, message: self.status.setText(message)
        )
        self.controller.busy_changed.connect(self._busy)
        self.input_path = None
        self.output_path = None
        self.result_data = None
        self.result_body = self.result_project = None
        self._close_pending = None
        layout = QVBoxLayout(self)
        title = QLabel("Create a part or modify a solid")
        title.setObjectName("section_title")
        layout.addWidget(title)
        self.form = QFormLayout()
        layout.addLayout(self.form)
        self.operation = QComboBox()
        for label, key in (
            ("Box", "box"),
            ("Cylinder", "cylinder"),
            ("Sphere", "sphere"),
            ("Extrude · XY rectangle", "extrude_rectangle"),
            ("Extrude · XY disk", "extrude_circle"),
            ("Extrude · dimensioned sketch", "extrude_sketch"),
            ("Subtract A − B", "cut"),
            ("Union A + B", "fuse"),
            ("Intersect A ∩ B", "common"),
            ("Fillet · all edges", "fillet"),
            ("Import STEP part", "import_step"),
            ("Export A to STEP", "export_step"),
        ):
            self.operation.addItem(label, key)
        self.form.addRow("Operation", self.operation)
        self.name = QLineEdit("CAD part")
        self.form.addRow("Name", self.name)
        self.a, self.b = QComboBox(), QComboBox()
        for body in project.bodies:
            self.a.addItem(body.name, body.id)
            self.b.addItem(body.name, body.id)
        index = self.a.findData(selection)
        if index >= 0:
            self.a.setCurrentIndex(index)
        if self.b.count() > 1:
            self.b.setCurrentIndex((self.a.currentIndex() + 1) % self.b.count())
        self.form.addRow("Body A · modified", self.a)
        self.form.addRow("Body B · retained", self.b)
        self.dimensions = [self.number(v, 0.001, 1e6, " mm") for v in (100, 60, 20)]
        for label, field in zip(("Length", "Width", "Height"), self.dimensions):
            self.form.addRow(label, field)
        self.profile = bracket_profile()
        self.profile_button = QPushButton("Edit profile… · dimensioned bracket")
        self.profile_button.clicked.connect(self.edit_profile)
        self.form.addRow("XY sketch", self.profile_button)
        self.sketch_height = NumberField(10.0)
        self.sketch_height.setAccessibleName("Sketch extrusion height in millimetres")
        self.form.addRow("Height [mm]", self.sketch_height)
        self.position = [self.number(0, -1e6, 1e6, " mm") for _ in range(3)]
        for axis, field in zip("XYZ", self.position):
            self.form.addRow("Position " + axis, field)
        self.density = self.number(7800, 0.001, 1e6, " kg/m³")
        self.form.addRow("Density", self.density)
        self.radius = self.number(1, 0.001, 1e6, " mm")
        self.form.addRow("Fillet radius", self.radius)
        self.explanation = QLabel("")
        self.explanation.setWordWrap(True)
        self.explanation.setObjectName("muted")
        layout.addWidget(self.explanation)
        self.status = QLabel()
        self.status.setWordWrap(True)
        self.controller.stage_changed.connect(self.status.setText)
        layout.addWidget(self.status)
        self.buttons = QDialogButtonBox(QDialogButtonBox.StandardButton.Cancel)
        self.apply_button = QPushButton("Create part")
        self.apply_button.setObjectName("primary")
        self.buttons.addButton(
            self.apply_button, QDialogButtonBox.ButtonRole.ActionRole
        )
        self.apply_button.clicked.connect(self.start)
        self.buttons.rejected.connect(self.reject)
        layout.addWidget(self.buttons)
        self.operation.currentIndexChanged.connect(self._fields)
        self.a.currentIndexChanged.connect(self._density_from_body)
        self._fields()

    @property
    def process(self):
        return self.controller.process

    def _busy(self, busy):
        if not busy and self._close_pending is not None:
            QTimer.singleShot(0, self._finish_close)
        self.apply_button.setEnabled(not busy)
        for row in range(self.form.rowCount()):
            item = self.form.itemAt(row, QFormLayout.ItemRole.FieldRole)
            if item and item.widget():
                item.widget().setEnabled(not busy)

    @staticmethod
    def number(value, minimum, maximum, suffix):
        field = QDoubleSpinBox()
        field.setDecimals(4)
        field.setRange(minimum, maximum)
        field.setValue(value)
        field.setSuffix(suffix)
        field.setKeyboardTracking(False)
        return field

    def _density_from_body(self):
        body = next(
            (b for b in self.project.bodies if b.id == self.a.currentData()), None
        )
        if body and body.cad:
            self.density.setValue(body.mass / body.cad.volume_m3)

    def _fields(self):
        operation = self.operation.currentData()
        edit = operation in ("cut", "fuse", "common", "fillet", "export_step")
        primitive = operation in (
            "box",
            "sphere",
            "cylinder",
            "extrude_rectangle",
            "extrude_circle",
            "extrude_sketch",
        )
        labels = (
            ("Radius", "Height")
            if operation in ("sphere", "cylinder", "extrude_circle")
            else ("Length", "Width", "Height")
        )
        count = {
            "box": 3,
            "sphere": 1,
            "cylinder": 2,
            "extrude_rectangle": 3,
            "extrude_circle": 2,
        }.get(operation, 0)
        for index, field in enumerate(self.dimensions):
            self.form.setRowVisible(field, index < count)
            if index < count:
                self.form.labelForField(field).setText(labels[index])
        for field in self.position:
            self.form.setRowVisible(field, primitive)
        self.form.setRowVisible(self.profile_button, operation == "extrude_sketch")
        self.form.setRowVisible(self.sketch_height, operation == "extrude_sketch")
        self.form.setRowVisible(self.name, not edit)
        self.form.setRowVisible(self.a, edit)
        self.form.setRowVisible(self.b, operation in ("cut", "fuse", "common"))
        self.form.setRowVisible(self.radius, operation == "fillet")
        self.form.setRowVisible(self.density, operation != "export_step")
        self.apply_button.setText(
            "Export…"
            if operation == "export_step"
            else "Import…"
            if operation == "import_step"
            else "Apply to A"
            if edit
            else "Create part"
        )
        self.explanation.setText(
            "Body B is retained. The result must be a single solid. Attachments keep their world positions."
            if operation in ("cut", "fuse", "common")
            else "The dimensioned XY sketch is extruded toward +Z. Position locates its design origin; editing dimensions preserves that origin."
            if operation == "extrude_sketch"
            else "XY profile extruded toward +Z. Position specifies the centre of the starting profile."
            if operation.startswith("extrude")
            else "OCCT reads STEP units. Import is limited to one solid part and 8 MB."
            if operation == "import_step"
            else "Geometry is stored as BREP; mass and inertia are computed from the exact volume, then converted to SI."
        )
        if edit:
            self._density_from_body()

    def request(self):
        operation = self.operation.currentData()
        count = {
            "box": 3,
            "sphere": 1,
            "cylinder": 2,
            "extrude_rectangle": 3,
            "extrude_circle": 2,
        }.get(operation, 0)
        result = {
            "operation": operation,
            "name": self.name.text(),
            "density": self.density.value(),
            "dimensions_mm": [f.value() for f in self.dimensions[:count]],
            "position_mm": [f.value() for f in self.position],
            "radius_mm": self.radius.value(),
        }
        if operation == "extrude_sketch":
            result["profile"] = asdict(self.profile)
            result["dimensions_mm"] = [self.sketch_height.value()]
        for key in ("a", "b"):
            body = next(
                (
                    body
                    for body in self.project.bodies
                    if body.id == getattr(self, key).currentData()
                ),
                None,
            )
            result[key] = asdict(body) if body else None
        return result

    def start(self):
        if self.process is not None:
            return
        try:
            request = self.request()
        except (ValueError, TypeError) as error:
            self.status.setText(str(error))
            return
        operation = request["operation"]
        if operation == "import_step":
            path, _ = QFileDialog.getOpenFileName(
                self, "Import STEP part", "", "STEP (*.step *.stp)"
            )
            if not path:
                return
            request["path"] = path
        elif operation == "export_step":
            path, _ = QFileDialog.getSaveFileName(
                self, "Export STEP part", "", "STEP (*.step *.stp)"
            )
            if not path:
                return
            self.output_path = Path(path)
        self.status.setText("CAD operation in progress…")
        try:
            self.controller.start(request)
        except (OSError, ValueError, TypeError, RuntimeError) as error:
            self.status.setText(str(error))

    def _completed(self, result):
        if self._close_pending is not None:
            return
        admission = self.controller.last_admission
        self.result_data = result
        self.result_body, self.result_project = admission.body, admission.project
        self.completed.emit(result)
        self.accept()

    def edit_profile(self):
        from .sketch_dialog import SketchDialog

        dialog = SketchDialog(self.profile, self)
        if dialog.exec() == QDialog.DialogCode.Accepted:
            self.profile = dialog.profile
            self.profile_button.setText(
                f"Edit profile… · {len(self.profile.edges)} segments"
            )

    def reject(self):
        self.done(QDialog.DialogCode.Rejected)

    @Slot()
    def _finish_close(self):
        if self._close_pending is not None:
            self.done(self._close_pending)

    def done(self, result):
        if self.controller.process is not None:
            self._close_pending = QDialog.DialogCode.Rejected
            self.controller.cancel()
            return
        self.controller.shutdown()
        super().done(result)
